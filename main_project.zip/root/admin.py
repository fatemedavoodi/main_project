from django.contrib import admin
from .models import *

admin.site.register(Team_members)
admin.site.register(Skills)
admin.site.register(Category)
admin.site.register(ContactUs)
admin.site.register(Request)
admin.site.register(Properties_company)