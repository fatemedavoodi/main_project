from django.contrib import admin
from .models import Services


admin.site.register(Services)
